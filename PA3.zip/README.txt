url_address:http://centaurus-7.ics.uci.edu:1040/PA3-1.0-SNAPSHOT/

phpmyadmin-user:root
phpmyadmin-password:gainsvilleDB

On the homepage you'll find a weclome page.
There is a navigation bar on the left and clicking on the products page will deploy the servlet to create the products page. (1)
Another servlet will be used on all pages for session tracking, you'll be able to see the last 5 viewed products below the below the navigation bar. (1)

Clicking on the image of a product on the products page will bring you to the product details page. (2)
On this page you'll be able to find additional images of the product and a description of it. You'll be able to add the product to your cart. (2)

At the top right of the page you'll be able to find a cart and checkout link. You can check your cart using the first link or go straight to checkout using the second. (3)
The check out page will load your cart and have a form for you to fill out with your information. (3)
Filling out this form and clicking "Place your order!" will bring you to a confirmation page and store the information in the database. (3)


